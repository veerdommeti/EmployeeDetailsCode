﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeDetails
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public object NavigationService { get; private set; }
        public Uri Source { get; private set; }

        public MainWindow()
        {
            InitializeComponent();
        }
          private void Employee_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Hide();
            this.Close();
            AddEmployee NewWindow = new AddEmployee();
            NewWindow.Show();  
        }
        private void EmployeeDetails_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Hide();
            this.Close();
            GetEmployeeDetails getEmployeeDetails = new GetEmployeeDetails();
            getEmployeeDetails.Show();
        }
        private void UpdateEmployee_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Hide();
            this.Close();
            UpdateEmployeeDetails updateEmployeeDetails = new UpdateEmployeeDetails();
            updateEmployeeDetails.Show();
        }
        private void DeleteEmployee_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Hide();
            this.Close();
            DeleteEmployee deleteEmployeeDetails = new DeleteEmployee();
            deleteEmployeeDetails.Show();
        }
       
    }
}

﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace EmployeeDetails
{
    /// <summary>
    /// Interaction logic for AddEmployee.xaml
    /// </summary>
    public partial class AddEmployee : Window
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Model.EmployeeData employeeData = new Model.EmployeeData();
                employeeData.name = txtEmployeeName.Text;
                employeeData.email = txtEmail.Text;
                employeeData.gender = cmbGender.SelectionBoxItem.ToString();
                employeeData.status=cmbStatus.SelectionBoxItem.ToString();

                HttpClient client = new HttpClient();
                
                client.BaseAddress = new Uri("https://gorest.co.in/public-api/users");
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", 
                    "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
                
                string json = JsonConvert.SerializeObject(employeeData);

                StringContent httpContent = new StringContent(json, System.Text.Encoding.UTF8, "application/json");
               
                
                HttpResponseMessage response = client.PostAsync(client.BaseAddress, httpContent).Result;
                if (response.IsSuccessStatusCode)
                {
                  MessageBox.Show("Saved Employee Details", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                    AddEmployee NewWindow = new AddEmployee();
                    NewWindow.Close();
                    this.Close();
                    MainWindow mainWindow = new MainWindow();
                    mainWindow.Show();
                }
            }
            catch (Exception ex)
            { 
            
            }
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            AddEmployee NewWindow = new AddEmployee();
            NewWindow.Close();
            this.Close();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }

    }
}

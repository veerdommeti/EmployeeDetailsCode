﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.Xml.Linq;
using Newtonsoft.Json;

namespace EmployeeDetails
{
    /// <summary>
    /// Interaction logic for GetEmployeeDetails.xaml
    /// </summary>
    public partial class GetEmployeeDetails : Window
    {
        public GetEmployeeDetails()
        {
            InitializeComponent();
            GetEmployeeList();
        }
        public void GetEmployeeList()
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://gorest.co.in/public-api/");
            client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer",
                    "fa114107311259f5f33e70a5d85de34a2499b4401da069af0b1d835cd5ec0d56");
            HttpResponseMessage response = client.GetAsync("users").Result;
            if (response.IsSuccessStatusCode)
            {
                List<Model.EmployeeData> empList = new List<Model.EmployeeData>();
                string result = response.Content.ReadAsStringAsync().Result;
                XmlDocument doc = (XmlDocument)JsonConvert.DeserializeXmlNode(result, "data");
                XmlNodeList nodes = doc.DocumentElement.SelectNodes("/data/data");
                List<Model.EmployeeData> employeeDataList = new List<Model.EmployeeData>();
                foreach (XmlNode node in nodes)
                {
                    Model.EmployeeData employeeData = new Model.EmployeeData();
                    employeeData.id = Convert.ToInt32(node.SelectSingleNode("id")?.InnerText);
                    employeeData.name = node.SelectSingleNode("name")?.InnerText;
                    employeeData.email = node.SelectSingleNode("email")?.InnerText;
                    employeeData.gender = node.SelectSingleNode("gender")?.InnerText;
                    employeeData.status = node.SelectSingleNode("status")?.InnerText;
                    employeeDataList.Add(employeeData);
                }
                EmployeeDetails.ItemsSource = null;
                EmployeeDetails.ItemsSource = employeeDataList;
            }
        }

        private void btnHome_Click(object sender, RoutedEventArgs e)
        {
            GetEmployeeDetails NewWindow = new GetEmployeeDetails();
            NewWindow.Close();
            this.Close();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
        }
    }
}
